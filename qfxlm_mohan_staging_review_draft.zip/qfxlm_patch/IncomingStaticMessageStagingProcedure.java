package com.citi.qlm.staticinterface.common.dao;

import java.math.BigDecimal;
import java.sql.Array;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.citi.common.core.util.CommonDBUtil;
import com.citi.qlm.staticinterface.common.exception.IncomingStaticStagingException;
import lombok.extern.log4j.Log4j2;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.DisposableSqlTypeValue;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.jdbc.object.StoredProcedure;

/** Spring JDBC wrapper for QLM_OWNER.PKG_QLM_INCOMING_STATIC_MSG.prc_log_incoming_static_msg. */
@Log4j2
public class IncomingStaticMessageStagingProcedure extends StoredProcedure {

    static final String PROCEDURE_NAME =
            "QLM_OWNER.PKG_QLM_INCOMING_STATIC_MSG.prc_log_incoming_static_msg";
    static final String COLLECTION_TYPE = "QLM_OWNER.TAB_INCOMING_STATIC_MSG";

    static final String P_STATIC_TYPE = "p_static_type";
    static final String P_FO_BRANCH_CODE = "p_fo_branch_code";
    static final String P_INCOMING_STATIC_MSG = "p_incoming_static_msg";
    static final String P_IN_OR_OUT = "p_in_or_out";
    static final String P_MSG_STATUS = "p_msg_status";
    static final String P_SOURCE_SYSTEM = "p_source_system";
    static final String P_SUCCESS_FLAG = "p_success_flag";
    static final String P_ERROR_MESSAGE = "p_error_message";
    static final String P_CUSTOMER_CODE = "p_customer_code";
    static final String P_CUSTOMER_ACC = "p_customer_acc";
    static final String P_MSG_TIMESTAMP = "p_msgtimestamp";

    public IncomingStaticMessageStagingProcedure(JdbcTemplate jdbcTemplate) {
        super(Objects.requireNonNull(jdbcTemplate, "jdbcTemplate"), PROCEDURE_NAME);
        declareParameter(new SqlParameter(P_STATIC_TYPE, Types.VARCHAR));
        declareParameter(new SqlParameter(P_FO_BRANCH_CODE, Types.VARCHAR));
        declareParameter(new SqlParameter(P_INCOMING_STATIC_MSG, Types.ARRAY, COLLECTION_TYPE));
        declareParameter(new SqlParameter(P_IN_OR_OUT, Types.VARCHAR));
        declareParameter(new SqlParameter(P_MSG_STATUS, Types.VARCHAR));
        declareParameter(new SqlParameter(P_SOURCE_SYSTEM, Types.VARCHAR));
        declareParameter(new SqlOutParameter(P_SUCCESS_FLAG, Types.VARCHAR));
        declareParameter(new SqlOutParameter(P_ERROR_MESSAGE, Types.VARCHAR));
        declareParameter(new SqlParameter(P_CUSTOMER_CODE, Types.VARCHAR));
        declareParameter(new SqlParameter(P_CUSTOMER_ACC, Types.VARCHAR));
        declareParameter(new SqlParameter(P_MSG_TIMESTAMP, Types.TIMESTAMP));
        compile();
    }

    public void execute(List<String> fragments, IncomingStaticMessageMetadata metadata) {
        Objects.requireNonNull(fragments, "fragments");
        Objects.requireNonNull(metadata, "metadata");
        try {
            metadata.validate();
        } catch (IllegalArgumentException exception) {
            throw new IncomingStaticStagingException("Invalid metadata passed to staging procedure", exception);
        }
        if (fragments.isEmpty()) {
            throw new IncomingStaticStagingException("No XML fragments provided for staging");
        }

        Map<String, Object> inParameters = new LinkedHashMap<>();
        inParameters.put(P_STATIC_TYPE, metadata.getStaticType());
        inParameters.put(P_FO_BRANCH_CODE, metadata.getFoBranchCode());
        inParameters.put(P_INCOMING_STATIC_MSG, new IncomingStaticMessageArrayValue(fragments));
        inParameters.put(P_IN_OR_OUT, metadata.getInOrOut());
        inParameters.put(P_MSG_STATUS, metadata.getMessageStatus());
        inParameters.put(P_SOURCE_SYSTEM, metadata.getSourceSystem());
        inParameters.put(P_CUSTOMER_CODE, metadata.getCustomerCode());
        inParameters.put(P_CUSTOMER_ACC, metadata.getCustomerAccount());
        inParameters.put(P_MSG_TIMESTAMP, metadata.getMessageTimestamp() == null
                ? new Timestamp(System.currentTimeMillis()) : metadata.getMessageTimestamp());

        final Map<String, Object> outParameters;
        try {
            outParameters = super.execute(inParameters);
        } catch (DataAccessException exception) {
            throw new IncomingStaticStagingException("Unable to execute incoming static staging procedure", exception);
        }

        String successFlag = outputValue(outParameters, P_SUCCESS_FLAG);
        String errorMessage = outputValue(outParameters, P_ERROR_MESSAGE);
        if (!"Y".equalsIgnoreCase(successFlag)) {
            throw new IncomingStaticStagingException(
                    "Incoming static staging procedure returned failure: " + safeError(errorMessage));
        }
        if (errorMessage != null && !errorMessage.isBlank()) {
            throw new IncomingStaticStagingException(
                    "Incoming static staging procedure returned an error: " + safeError(errorMessage));
        }
    }

    private static String outputValue(Map<String, Object> outParameters, String parameterName) {
        if (outParameters == null) {
            return null;
        }
        Object value = outParameters.get(parameterName);
        return value == null ? null : value.toString();
    }

    private static String safeError(String errorMessage) {
        return errorMessage == null || errorMessage.isBlank()
                ? "no database error message" : errorMessage;
    }

    /**
     * Adapter for the existing CommonDBUtil array factory, bound to the SAME JDBC connection
     * Spring uses for the stored procedure. SingleConnectionDataSource suppresses close():
     * the helper's try-with-resources therefore must not close Spring's active connection.
     */
    static final class IncomingStaticMessageArrayValue implements DisposableSqlTypeValue {
        private final List<String> fragments;
        private Array oracleArray;

        IncomingStaticMessageArrayValue(List<String> fragments) {
            this.fragments = List.copyOf(Objects.requireNonNull(fragments, "fragments"));
        }

        @Override
        public void setTypeValue(
                PreparedStatement statement, int parameterIndex, int sqlType, String typeName)
                throws SQLException {
            Object[][] rows = new Object[fragments.size()][2];
            for (int i = 0; i < fragments.size(); i++) {
                rows[i][0] = BigDecimal.valueOf(i + 1L);
                rows[i][1] = fragments.get(i);
            }

            // CommonDBUtil normally calls dataSource.getConnection() and closes that handle.
            // The close-suppressing wrapper makes it use Spring's exact active connection.
            JdbcTemplate sameConnectionTemplate = new JdbcTemplate(
                    new SingleConnectionDataSource(statement.getConnection(), true));
            oracleArray = CommonDBUtil.getOracleTagArrayFromObjArray(
                    rows, COLLECTION_TYPE, sameConnectionTemplate);
            statement.setArray(parameterIndex, oracleArray);
        }

        @Override
        public void cleanup() {
            if (oracleArray == null) {
                return;
            }
            try {
                oracleArray.free();
            } catch (SQLException exception) {
                log.warn("Unable to free incoming-static Oracle ARRAY", exception);
            } finally {
                oracleArray = null;
            }
        }
    }
}
