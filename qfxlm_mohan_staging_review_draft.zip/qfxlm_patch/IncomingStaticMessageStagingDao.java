package com.citi.qlm.staticinterface.common.dao;

import java.util.List;
import java.util.Objects;
import java.util.function.Function;

import com.citi.qlm.staticinterface.common.exception.IncomingStaticStagingException;
import com.citi.qlm.staticinterface.common.util.IncomingStaticXmlChunker;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/** Reusable DAO for logging original incoming MLV XML into the staging tables. */
@Log4j2
@Repository
public class IncomingStaticMessageStagingDao {

    private final JdbcTemplate jdbcTemplate;
    private final Function<JdbcTemplate, IncomingStaticMessageStagingProcedure> procedureFactory;

    @Autowired
    public IncomingStaticMessageStagingDao(JdbcTemplate jdbcTemplate) {
        this(jdbcTemplate, IncomingStaticMessageStagingProcedure::new);
    }

    // Package-private seam: test the DAO without opening Oracle connections.
    IncomingStaticMessageStagingDao(
            JdbcTemplate jdbcTemplate,
            Function<JdbcTemplate, IncomingStaticMessageStagingProcedure> procedureFactory) {
        this.jdbcTemplate = Objects.requireNonNull(jdbcTemplate, "jdbcTemplate");
        this.procedureFactory = Objects.requireNonNull(procedureFactory, "procedureFactory");
    }

    /** Validates, chunks and stages the unchanged raw XML; returns only on database success. */
    public void stage(String rawXml, IncomingStaticMessageMetadata metadata) {
        if (rawXml == null) {
            throw new IncomingStaticStagingException("rawXml is required for incoming static staging");
        }
        if (rawXml.isBlank()) {
            throw new IncomingStaticStagingException("rawXml cannot be blank for incoming static staging");
        }
        if (metadata == null) {
            throw new IncomingStaticStagingException("staging metadata is required for incoming static staging");
        }

        try {
            metadata.validate();
        } catch (IllegalArgumentException exception) {
            throw new IncomingStaticStagingException("Invalid incoming static staging metadata", exception);
        }

        List<String> fragments = IncomingStaticXmlChunker.split(rawXml);
        // Mohan's review: a separate StoredProcedure instance for every staging call.
        IncomingStaticMessageStagingProcedure procedure = procedureFactory.apply(jdbcTemplate);
        procedure.execute(fragments, metadata);

        log.info("Incoming static message staged with {} fragment(s), type={}, source={}",
                fragments.size(), metadata.getStaticType(), metadata.getSourceSystem());
    }
}
