package com.citi.qlm.staticinterface.common.dao;

import java.math.BigDecimal;
import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import com.citi.qlm.staticinterface.common.exception.IncomingStaticStagingException;
import oracle.jdbc.OracleConnection;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

class IncomingStaticMessageStagingProcedureTest {

    @Test
    void declaresAndCompilesExactElevenParameterContract() {
        TestableProcedure procedure = new TestableProcedure(mock(JdbcTemplate.class));
        assertTrue(procedure.isCompiled());
        assertEquals(IncomingStaticMessageStagingProcedure.PROCEDURE_NAME, procedure.getSql());
        assertEquals(11, procedure.getCallString().chars().filter(c -> c == '?').count());
        List<SqlParameter> parameters = procedure.parameters();
        assertEquals(List.of(
                "p_static_type", "p_fo_branch_code", "p_incoming_static_msg",
                "p_in_or_out", "p_msg_status", "p_source_system",
                "p_success_flag", "p_error_message", "p_customer_code",
                "p_customer_acc", "p_msgtimestamp"),
                parameters.stream().map(SqlParameter::getName).toList());
        assertEquals(List.of(
                Types.VARCHAR, Types.VARCHAR, Types.ARRAY, Types.VARCHAR,
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP),
                parameters.stream().map(SqlParameter::getSqlType).toList());
        assertEquals(IncomingStaticMessageStagingProcedure.COLLECTION_TYPE,
                parameters.get(2).getTypeName());
        assertInstanceOf(SqlOutParameter.class, parameters.get(6));
        assertInstanceOf(SqlOutParameter.class, parameters.get(7));
    }

    @Test
    void rejectsInvalidMetadataBeforeOpeningDatabaseCall() {
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
        IncomingStaticMessageStagingProcedure procedure =
                new IncomingStaticMessageStagingProcedure(jdbcTemplate);
        IncomingStaticMessageMetadata invalid = new IncomingStaticMessageMetadata(
                "MLV_CUSMSG_ADR", null, "I", null, "MLV", null, null, null);
        List<String> fragments = List.of("xml");

        IncomingStaticStagingException exception = assertThrows(
                IncomingStaticStagingException.class,
                () -> procedure.execute(fragments, invalid));

        assertTrue(exception.getMessage().contains("Invalid metadata"));
        verifyNoInteractions(jdbcTemplate);
    }

    @Test
    void rejectsEmptyFragmentsBeforeOpeningDatabaseCall() {
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
        IncomingStaticMessageStagingProcedure procedure =
                new IncomingStaticMessageStagingProcedure(jdbcTemplate);
        List<String> fragments = List.of();
        IncomingStaticMessageMetadata metadata = metadata();

        assertThrows(IncomingStaticStagingException.class,
                () -> procedure.execute(fragments, metadata));
        verifyNoInteractions(jdbcTemplate);
    }

    @Test
    void wrapsDatabaseAccessFailure() {
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
        when(jdbcTemplate.call(any(CallableStatementCreator.class), anyList()))
                .thenThrow(new DataAccessResourceFailureException("database unavailable"));
        IncomingStaticMessageStagingProcedure procedure =
                new IncomingStaticMessageStagingProcedure(jdbcTemplate);
        List<String> fragments = List.of("xml");
        IncomingStaticMessageMetadata metadata = metadata();

        IncomingStaticStagingException exception = assertThrows(
                IncomingStaticStagingException.class,
                () -> procedure.execute(fragments, metadata));

        assertTrue(exception.getMessage().contains("Unable to execute"));
    }

    @Test
    void rejectsNonBlankDatabaseErrorEvenWhenSuccessFlagIsYes() {
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
        when(jdbcTemplate.call(any(CallableStatementCreator.class), anyList()))
                .thenReturn(Map.of(
                        IncomingStaticMessageStagingProcedure.P_SUCCESS_FLAG, "Y",
                        IncomingStaticMessageStagingProcedure.P_ERROR_MESSAGE, "warning"));
        IncomingStaticMessageStagingProcedure procedure =
                new IncomingStaticMessageStagingProcedure(jdbcTemplate);
        List<String> fragments = List.of("xml");
        IncomingStaticMessageMetadata metadata = metadata();

        IncomingStaticStagingException exception = assertThrows(
                IncomingStaticStagingException.class,
                () -> procedure.execute(fragments, metadata));

        assertTrue(exception.getMessage().contains("warning"));
    }

    @Test
    void rejectsMissingOutputParameters() {
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
        when(jdbcTemplate.call(any(CallableStatementCreator.class), anyList()))
                .thenReturn(Map.of());
        IncomingStaticMessageStagingProcedure procedure =
                new IncomingStaticMessageStagingProcedure(jdbcTemplate);
        List<String> fragments = List.of("xml");
        IncomingStaticMessageMetadata metadata = metadata();

        IncomingStaticStagingException exception = assertThrows(
                IncomingStaticStagingException.class,
                () -> procedure.execute(fragments, metadata));

        assertTrue(exception.getMessage().contains("no database error message"));
    }

    @Test
    void acceptsSuccessfulProcedureResponse() {
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
        when(jdbcTemplate.call(any(CallableStatementCreator.class), anyList()))
                .thenReturn(Map.of(
                        IncomingStaticMessageStagingProcedure.P_SUCCESS_FLAG, "Y",
                        IncomingStaticMessageStagingProcedure.P_ERROR_MESSAGE, ""));
        IncomingStaticMessageStagingProcedure procedure =
                new IncomingStaticMessageStagingProcedure(jdbcTemplate);
        List<String> fragments = List.of("xml");
        IncomingStaticMessageMetadata metadata = metadata();

        assertDoesNotThrow(() -> procedure.execute(fragments, metadata));
    }

    @Test
    void arrayUsesExistingUtilityWithoutSplittingOrReorderingAndFreesAfterUse() throws Exception {
        PreparedStatement statement = mock(PreparedStatement.class);
        Connection connection = mock(Connection.class);
        OracleConnection oracleConnection = mock(OracleConnection.class);
        Array oracleArray = mock(Array.class);
        when(statement.getConnection()).thenReturn(connection);
        when(connection.unwrap(OracleConnection.class)).thenReturn(oracleConnection);
        when(oracleConnection.createOracleArray(anyString(), any(Object[].class)))
                .thenReturn(oracleArray);
        IncomingStaticMessageStagingProcedure.IncomingStaticMessageArrayValue value =
                new IncomingStaticMessageStagingProcedure.IncomingStaticMessageArrayValue(
                        List.of("a", "🙂"));

        value.setTypeValue(statement, 3, Types.ARRAY,
                IncomingStaticMessageStagingProcedure.COLLECTION_TYPE);

        ArgumentCaptor<Object[]> records = ArgumentCaptor.forClass(Object[].class);
        verify(oracleConnection).createOracleArray(
                eq(IncomingStaticMessageStagingProcedure.COLLECTION_TYPE), records.capture());
        Object[] rows = records.getValue();
        assertEquals(2, rows.length);
        Object[] first = (Object[]) rows[0];
        Object[] second = (Object[]) rows[1];
        assertEquals(BigDecimal.ONE, first[0]);
        assertEquals("a", first[1]);
        assertEquals(BigDecimal.valueOf(2), second[0]);
        assertEquals("🙂", second[1]);
        verify(statement).setArray(3, oracleArray);

        value.cleanup();
        verify(oracleArray).free();
        verify(connection, never()).close();
        assertDoesNotThrow(value::cleanup);
    }

    @Test
    void arrayCleanupSuppressesFreeFailure() throws Exception {
        PreparedStatement statement = mock(PreparedStatement.class);
        Connection connection = mock(Connection.class);
        OracleConnection oracleConnection = mock(OracleConnection.class);
        Array oracleArray = mock(Array.class);
        when(statement.getConnection()).thenReturn(connection);
        when(connection.unwrap(OracleConnection.class)).thenReturn(oracleConnection);
        when(oracleConnection.createOracleArray(anyString(), any(Object[].class)))
                .thenReturn(oracleArray);
        doThrow(new SQLException("free failed")).when(oracleArray).free();
        IncomingStaticMessageStagingProcedure.IncomingStaticMessageArrayValue value =
                new IncomingStaticMessageStagingProcedure.IncomingStaticMessageArrayValue(
                        List.of("xml"));
        value.setTypeValue(statement, 3, Types.ARRAY,
                IncomingStaticMessageStagingProcedure.COLLECTION_TYPE);

        assertDoesNotThrow(value::cleanup);
        assertDoesNotThrow(value::cleanup);
        verify(oracleArray).free();
    }

    @Test
    void arrayCreationFailureIsNotSilentlyIgnored() throws Exception {
        PreparedStatement statement = mock(PreparedStatement.class);
        Connection connection = mock(Connection.class);
        OracleConnection oracleConnection = mock(OracleConnection.class);
        when(statement.getConnection()).thenReturn(connection);
        when(connection.unwrap(OracleConnection.class)).thenReturn(oracleConnection);
        when(oracleConnection.createOracleArray(anyString(), any(Object[].class)))
                .thenThrow(new SQLException("Oracle array creation failed"));
        IncomingStaticMessageStagingProcedure.IncomingStaticMessageArrayValue value =
                new IncomingStaticMessageStagingProcedure.IncomingStaticMessageArrayValue(
                        List.of("xml"));

        assertThrows(SQLException.class,
                () -> value.setTypeValue(statement, 3, Types.ARRAY,
                        IncomingStaticMessageStagingProcedure.COLLECTION_TYPE));
        assertDoesNotThrow(value::cleanup);
    }

    private static IncomingStaticMessageMetadata metadata() {
        return new IncomingStaticMessageMetadata(
                "MLV_CUSMSG_ADR", "IE6", "I", null, "MLV", "715484", null,
                Timestamp.valueOf("2026-10-21 10:11:12.123"));
    }

    private static final class TestableProcedure extends IncomingStaticMessageStagingProcedure {
        private TestableProcedure(JdbcTemplate jdbcTemplate) {
            super(jdbcTemplate);
        }

        private List<SqlParameter> parameters() {
            return getDeclaredParameters();
        }
    }
}
