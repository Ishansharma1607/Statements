QFXLM CUSTOMER MESSAGE ADDRESS — PROPOSED MOHAN REVIEW PATCH

These four files are a source-level draft based on photographs. They have NOT been compiled against Citi's private project dependencies or executed against Oracle or MQ. Do not commit or push them before a local build and test run.

CONTENTS:
1. IncomingStaticMessageStagingDao.java
2. IncomingStaticMessageStagingProcedure.java
3. IncomingStaticMessageStagingDaoTest.java
4. IncomingStaticMessageStagingProcedureTest.java

IMPORTANT:
- Preserve the current project files before replacing them; inspect the diff for unintended changes.
- The proposed new StoredProcedure instance is created per DAO.stage() invocation, while DAO remains @Repository.
- The StoredProcedure is NOT a Spring @Component.
- The code uses com.citi.common.core.util.CommonDBUtil.getOracleTagArrayFromObjArray, as Mohan requested.
- The connection-bound SingleConnectionDataSource adapter is important: the utility normally opens a separate connection. This version exposes the same Spring PreparedStatement connection to it, suppressing premature close. Verify compatibility with the helper's exact runtime implementation.
- Verify CommonDBUtil is on this application's classpath and its signature matches (Object[][], String, JdbcTemplate).
- The test files are reconstructed from screenshots, not verbatim copies of the existing full tests. Preserve any additional old tests not represented here to avoid reducing coverage.
- This patch intentionally does NOT cover Mohan's other receiver/processor/exceptions/converter review comments.
- No live database writes or MQ messages were attempted.

Before considering ready:
1. Check package and import paths against the current repository.
2. Ensure no unrelated files or local-only DB_PASS settings were changed.
3. Run the project's existing Gradle compile and focused JUnit tasks.
4. Run Sonar and compare test count and JaCoCo coverage before/after.
5. Run actual DEV staging only after approved access/test coordination; verify Oracle ARRAY binding and rollback/error behavior.
