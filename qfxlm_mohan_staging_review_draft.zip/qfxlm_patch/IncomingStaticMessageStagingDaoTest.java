package com.citi.qlm.staticinterface.common.dao;

import java.sql.Timestamp;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import com.citi.qlm.staticinterface.common.exception.IncomingStaticStagingException;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.jdbc.core.JdbcTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

class IncomingStaticMessageStagingDaoTest {

    @Test
    void preservesAndChunksRawUnicodeXmlInOrder() {
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
        IncomingStaticMessageStagingProcedure procedure = mock(IncomingStaticMessageStagingProcedure.class);
        IncomingStaticMessageStagingDao dao =
                new IncomingStaticMessageStagingDao(jdbcTemplate, ignored -> procedure);
        String rawXml = "a".repeat(3_999) + "🙂" + "b";
        IncomingStaticMessageMetadata metadata = metadata();

        dao.stage(rawXml, metadata);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<List<String>> fragmentsCaptor = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<IncomingStaticMessageMetadata> metadataCaptor =
                ArgumentCaptor.forClass(IncomingStaticMessageMetadata.class);
        verify(procedure).execute(fragmentsCaptor.capture(), metadataCaptor.capture());
        assertEquals(2, fragmentsCaptor.getValue().size());
        assertEquals("a".repeat(3_999) + "🙂", fragmentsCaptor.getValue().get(0));
        assertEquals("b", fragmentsCaptor.getValue().get(1));
        assertEquals(rawXml, String.join("", fragmentsCaptor.getValue()));
        assertSame(metadata, metadataCaptor.getValue());
    }

    @Test
    void propagatesProcedureFailure() {
        IncomingStaticMessageStagingProcedure procedure = mock(IncomingStaticMessageStagingProcedure.class);
        IncomingStaticMessageStagingDao dao = dao(procedure);
        IncomingStaticStagingException failure =
                new IncomingStaticStagingException("S02~unknown branch");
        doThrow(failure).when(procedure).execute(anyList(), any(IncomingStaticMessageMetadata.class));
        IncomingStaticMessageMetadata metadata = metadata();

        IncomingStaticStagingException thrown = assertThrows(
                IncomingStaticStagingException.class,
                () -> dao.stage("<flexstatic/>", metadata));

        assertSame(failure, thrown);
    }

    @Test
    void rejectsBlankXmlBeforeExecutingProcedure() {
        IncomingStaticMessageStagingProcedure procedure = mock(IncomingStaticMessageStagingProcedure.class);
        IncomingStaticMessageStagingDao dao = dao(procedure);
        IncomingStaticMessageMetadata metadata = metadata();

        assertThrows(IncomingStaticStagingException.class, () -> dao.stage(" \t\r\n", metadata));
        verifyNoInteractions(procedure);
    }

    @Test
    void rejectsNullXmlBeforeExecutingProcedure() {
        IncomingStaticMessageStagingProcedure procedure = mock(IncomingStaticMessageStagingProcedure.class);
        IncomingStaticMessageStagingDao dao = dao(procedure);
        IncomingStaticMessageMetadata metadata = metadata();

        assertThrows(IncomingStaticStagingException.class, () -> dao.stage(null, metadata));
        verifyNoInteractions(procedure);
    }

    @Test
    void rejectsNullMetadataBeforeExecutingProcedure() {
        IncomingStaticMessageStagingProcedure procedure = mock(IncomingStaticMessageStagingProcedure.class);
        IncomingStaticMessageStagingDao dao = dao(procedure);

        assertThrows(IncomingStaticStagingException.class, () -> dao.stage("<flexstatic/>", null));
        verifyNoInteractions(procedure);
    }

    @Test
    void rejectsInvalidMetadataBeforeExecutingProcedure() {
        IncomingStaticMessageStagingProcedure procedure = mock(IncomingStaticMessageStagingProcedure.class);
        IncomingStaticMessageStagingDao dao = dao(procedure);
        IncomingStaticMessageMetadata invalidMetadata = new IncomingStaticMessageMetadata(
                "MLV_CUSMSG_ADR", null, "I", null, "MLV", null, null, null);

        IncomingStaticStagingException thrown = assertThrows(
                IncomingStaticStagingException.class,
                () -> dao.stage("<flexstatic/>", invalidMetadata));

        assertTrue(thrown.getMessage().contains("Invalid incoming static staging metadata"));
        verifyNoInteractions(procedure);
    }

    @Test
    void createsFreshProcedureForEveryStagingInvocation() {
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
        AtomicInteger creations = new AtomicInteger();
        IncomingStaticMessageStagingProcedure first = mock(IncomingStaticMessageStagingProcedure.class);
        IncomingStaticMessageStagingProcedure second = mock(IncomingStaticMessageStagingProcedure.class);
        IncomingStaticMessageStagingDao dao = new IncomingStaticMessageStagingDao(
                jdbcTemplate,
                ignored -> creations.getAndIncrement() == 0 ? first : second);
        IncomingStaticMessageMetadata metadata = metadata();

        dao.stage("<flexstatic id='1'/>", metadata);
        dao.stage("<flexstatic id='2'/>", metadata);

        assertEquals(2, creations.get());
        verify(first).execute(anyList(), any(IncomingStaticMessageMetadata.class));
        verify(second).execute(anyList(), any(IncomingStaticMessageMetadata.class));
        verify(first, never()).execute(List.of("<flexstatic id='2'/>"), metadata);
    }

    private static IncomingStaticMessageStagingDao dao(IncomingStaticMessageStagingProcedure procedure) {
        return new IncomingStaticMessageStagingDao(mock(JdbcTemplate.class), ignored -> procedure);
    }

    private static IncomingStaticMessageMetadata metadata() {
        return new IncomingStaticMessageMetadata(
                "MLV_CUSMSG_ADR", "IE6", "I", null, "MLV", "715484", null,
                Timestamp.valueOf("2026-10-21 10:11:12.123"));
    }
}
